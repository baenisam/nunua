module.exports = {
    client: {
        service: {
            url: 'https://d-themes.com/graphql'
        }
    }
}